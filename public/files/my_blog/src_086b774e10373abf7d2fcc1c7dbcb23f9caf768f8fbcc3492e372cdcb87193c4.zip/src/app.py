import os
import re
import secrets
from urllib.parse import urlparse, urlunparse

import requests
import sqlite3
from flask import Flask, request, render_template, redirect


FLAG = os.environ.get("FLAG", "zeroday{dummy_flag_for_testing}")
TOURIST_URL = os.environ.get("TOURIST_URL", "https://tourist.hcknt.xyz")
ADMIN_SECRET = os.environ.get("ADMIN_SECRET", secrets.token_hex(32))


# fmt: off
WAF_PATTERNS = [
    '<script', '</script', 'script>',
    'onerror', 'onload', 'onclick', 'onmouseover', 'onfocus', 'onblur',
    'onsubmit', 'onchange', 'oninput', 'onkeydown', 'onkeyup', 'onkeypress',
    'ondblclick', 'onmousedown', 'onmouseup', 'onmousemove', 'onmouseout',
    'oncontextmenu', 'ondrag', 'ondrop', 'oncopy', 'oncut', 'onpaste',
    'onscroll', 'onwheel', 'ontouchstart', 'ontouchend', 'ontouchmove',
    'onanimationend', 'ontransitionend', 'onpointerdown', 'onpointerup',
    '<svg', '<img', '<iframe', '<object', '<embed', '<body', '<video',
    '<audio', '<source', '<input', '<button', '<form', '<textarea',
    '<select', '<link', '<style', '<meta', '<base', '<frame', '<frameset',
    '<marquee', '<bgsound', '<applet', '<math', '<table',
    'javascript:', 'vbscript:', 'data:text', 'data:image',
    'alert(', 'confirm(', 'prompt(', 'eval(', 'function(', 'function (',
    'settimeout', 'setinterval', 'new function',
    'document.', 'window.', '.cookie', '.innerhtml', '.outerhtml',
    '.textcontent', '.src=', '.href=', 'srcdoc',
    'expression(', 'url(', '@import', 'binding:', '-moz-binding',
    'fromcharcode', 'String.', 'atob(', 'btoa(',
]
# fmt: on

CENSORED_WORDS = ["politechnika krakowska", "uniwersytet jagielloński"]


def init_db():
    conn = sqlite3.connect("blog.db")
    c = conn.cursor()
    c.execute(
        """CREATE TABLE IF NOT EXISTS posts (id INTEGER PRIMARY KEY, title TEXT, content TEXT, status TEXT)"""
    )
    c.execute("SELECT COUNT(*) FROM posts")

    if c.fetchone()[0] == 0:
        c.execute(
            "INSERT INTO posts (title, content, status) VALUES (?, ?, ?)",
            (
                "hiiiiii :3",
                'this is my first post.<br><br>you can add yours on main page, but no cool images or gifs !<br><br> <img src="https://blob.gifcities.org/gifcities/IKRYJX2VZN4I2WZIBDQHVJAFZEAY43BT.gif"><br><br>cya, admin',
                "ok",
            ),
        )
        c.execute(
            "INSERT INTO posts (title, content, status) VALUES (?, ?, ?)",
            ("cat pictures", "", "waf"),
        )
        c.execute(
            "INSERT INTO posts (title, content, status) VALUES (?, ?, ?)",
            (
                "this blog sucks",
                "i cant add images ????? xd ?? <br><br> at least i hope it grants security, anyway this site is a joke and coded by probably toddler <br><br> x_sk8t3r1997_x",
                "ok",
            ),
        )

    conn.commit()
    conn.close()


def check_waf(content):
    content_lower = content.lower()

    for pattern in WAF_PATTERNS:
        if pattern.lower() in content_lower:
            return False

    return True


def censor_content(content):
    censored = False
    result = content

    for word in CENSORED_WORDS:
        if word.lower() in result.lower():
            censored = True
            result = re.sub(re.escape(word), "", result, flags=re.IGNORECASE)

    return result, censored


def trigger_admin_bot(post_id):
    base = urlparse(request.base_url)
    post_url = urlunparse((base.scheme, base.netloc, f"/post/{post_id}", "", "", ""))

    requests.post(
        f"{TOURIST_URL}/api/v1/async-job",
        json={
            "steps": [{"url": post_url}],
            "cookies": [
                {
                    "name": "admin_session",
                    "value": ADMIN_SECRET,
                    "domain": base.hostname,
                    "path": "/",
                }
            ],
        },
    )


def index():
    conn = sqlite3.connect("blog.db")
    c = conn.cursor()
    c.execute("SELECT id, title, status FROM posts ORDER BY id DESC")
    posts = c.fetchall()
    conn.close()
    return render_template("index.html", posts=posts)


def admin():
    cookie = request.cookies.get("admin_session")

    if cookie == ADMIN_SECRET:
        return render_template("admin.html", flag=FLAG)

    return (
        '<DOCTYPE html><html><body><h1>Access denied, you are not admin</h1><br><br><img src="https://blob.gifcities.org/gifcities/EZ7MHLSROGJTPBZ4WVSQAZUSWVB42UGY.gif"></body></html>',
        403,
    )


def post_view(post_id):
    conn = sqlite3.connect("blog.db")
    c = conn.cursor()
    c.execute("SELECT title, content, status FROM posts WHERE id = ?", (post_id,))
    post = c.fetchone()
    conn.close()

    if not post:
        return "no post", 404

    return render_template("post.html", title=post[0], content=post[1], status=post[2])


def post_add():
    if request.method == "POST":
        title = request.form.get("title", "")
        content = request.form.get("content", "")

        if not check_waf(title) or not check_waf(content):
            conn = sqlite3.connect("blog.db")

            c = conn.cursor()
            c.execute(
                "INSERT INTO posts (title, content, status) VALUES (?, ?, ?)",
                (title, "[BLOCKED]", "waf"),
            )
            conn.commit()
            post_id = c.lastrowid
            conn.close()
            return redirect(f"/post/{post_id}")

        censored_title, title_censored = censor_content(title)
        censored_content, content_censored = censor_content(content)

        conn = sqlite3.connect("blog.db")
        c = conn.cursor()
        c.execute(
            "INSERT INTO posts (title, content, status) VALUES (?, ?, ?)",
            (censored_title, censored_content, "ok"),
        )
        conn.commit()
        post_id = c.lastrowid
        conn.close()

        trigger_admin_bot(post_id)
        return redirect(f"/post/{post_id}")

    return render_template("add.html")


def create_app(*args, **kwargs):
    app = Flask(__name__)
    init_db()

    app.add_url_rule("/", view_func=index)
    app.add_url_rule("/admin", view_func=admin)
    app.add_url_rule("/add", view_func=post_add, methods=["GET", "POST"])
    app.add_url_rule("/post/<int:post_id>", view_func=post_view)

    return app