from flask import Flask, request, jsonify
from playwright.sync_api import sync_playwright
import threading

app = Flask(__name__)

def visit_url(url, cookies):
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context()
        
        # Add cookies to context
        context.add_cookies(cookies)
        
        page = context.new_page()
        page.goto(url, timeout=10000)
        page.wait_for_timeout(3000)
        
        browser.close()

@app.route("/visit", methods=["POST"])
def visit():
    data = request.json
    url = data.get("url")
    cookies = data.get("cookies", [])
    
    if not url:
        return jsonify({"error": "url required"}), 400
    
    thread = threading.Thread(target=visit_url, args=(url, cookies))
    thread.start()
    
    return jsonify({"status": "ok"})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=3000)
